Created by TF2Prophete
An RSS Production

Video Demo: https://youtu.be/D7-uaugvX0g

Special thanks to Alexander Samuelsson 
AKA AdmiralAlkex for 
JSON/Data Retrieve Sections